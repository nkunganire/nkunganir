
// dashboard.js

// Adding search functionality (placeholder for now)
document.getElementById("search-input").addEventListener("keyup", function () {
    console.log("Search input: ", this.value);
});
